# Story Master Challenge — Version 3 Setup

Version 3 changes the leaderboard from browser-only storage to a **shared online database**.

Students can use the same game link on different devices, submit scores, and see the same class leaderboard. The teacher dashboard reads the same database.

This version uses **Supabase** for the database and **GitHub Pages** (or another static host) for the website. Supabase provides browser JavaScript access to a Postgres database, including insert/select operations. GitHub Pages can host the static HTML/JavaScript files. 

## 1. Create the shared database

1. Create a Supabase project.
2. Open the project's **SQL Editor**.
3. Open `supabase_setup.sql` from this package.
4. Paste the entire SQL file into the SQL Editor.
5. Run it.
6. In Supabase's Data API settings, make sure `story_master_scores` is exposed if your project asks you to expose tables.

The SQL creates a table named `story_master_scores` and Row Level Security policies for the public browser client. The browser is allowed to **insert scores** and **read scores**, but the package does not put a service-role secret in the website.

## 2. Get the two Supabase browser values

In Supabase, find your project's:
- Project URL
- Publishable/anon browser key

Put them into `config.js`:

```js
window.STORY_MASTER_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-PUBLISHABLE-OR-ANON-KEY",
  CLASS_ID: "ELA_PERIOD_3"
};
```

Choose a class ID such as `ELA_PERIOD_3` or `2026_FALL_ELA`. Students do not need to know or enter the class ID.

**Important:** Use only the publishable/anon browser key in `config.js`. Never put a Supabase `service_role` key in a browser file.

## 3. Publish the website

Upload these files to the same website:
- `index.html`
- `teacher.html`
- `config.js`

GitHub Pages looks for an `index.html` entry file and can publish a static HTML/JavaScript site.

## 4. Give students the game link

Once GitHub Pages finishes publishing, give students:

`https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPOSITORY/`

They click the link, enter their name, play, and their score is submitted to the shared database.

## 5. Use the teacher dashboard

Open:

`https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPOSITORY/teacher.html`

The dashboard includes:
- shared leaderboard
- refresh button
- score count
- CSV download
- link back to the student game

## Important security/teacher note

The supplied version intentionally does **not** include a browser-based "delete all scores" button. A teacher code stored inside a public HTML file would not be a secure password because students could inspect the code.

If you want a secure teacher-only dashboard with login and score management, that should be Version 4 using Supabase Authentication.

## Troubleshooting

### "Setup needed"
`config.js` still contains one or more `YOUR_...` placeholders.

### "Could not load the shared leaderboard"
Check:
- Supabase URL
- publishable/anon key
- `CLASS_ID`
- that the SQL was run
- that the table is exposed through the Supabase Data API

### Students can play but scores do not appear
Check the browser console and Supabase table/policies. The SQL file creates the required SELECT and INSERT policies.

### The website is blank or 404
Make sure `index.html` is at the top level of the published folder/repository and that GitHub Pages is publishing from the correct branch/folder.
