// Story Master Challenge — Version 3 configuration
// Paste your Supabase project URL, publishable/anon key, and a class ID here.
// Do NOT put a Supabase service_role key in this file.

window.STORY_MASTER_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_PROJECT_URL",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY",
  CLASS_ID: "YOUR_CLASS_ID"
};
