# Story Master Challenge — Version 3

A web-hosting-ready version of the Literary Elements Story Master Challenge with a genuinely shared online leaderboard.

Files:
- `index.html` — student game
- `teacher.html` — teacher dashboard
- `config.js` — Supabase connection settings (fill this in)
- `supabase_setup.sql` — creates the shared leaderboard database
- `SETUP.md` — step-by-step setup and hosting instructions

The game content remains based on the Version 2 game.
